require 'rubygems'
require 'spec'
require 'fakeweb'

$:.unshift(File.dirname(__FILE__) + '/../lib')
require 'tweet_checker'
